from django.shortcuts import render, HttpResponse
from .models import Student, ClassInfo, Counselor
from course.models import Department, Major
from django.http import JsonResponse
# Create your views here.


def index(request):
    return HttpResponse('This is the student index')


# 返回所有用户数据
def get_all_student_information(request):
    if request.method == "GET":
        all_students_information = {
                "has_data": False,
                "data_list": []
            }
        all_students_obj = Student.objects.all()
        print(len(all_students_obj))
        for stu_obj in all_students_obj:
            all_students_information['hasData'] = True
            temp_data = {
                "student_id": stu_obj.student_id,
                "student_name": stu_obj.student_name,
                "student_grade": stu_obj.student_grade,
                "department_id": Department.objects.filter(department_id=
                                                             stu_obj.department_id.department_id)[0].department_id,
                "department_name": Department.objects.filter(department_id=
                                                             stu_obj.department_id.department_id)[0].department_name,
                "class_id": ClassInfo.objects.filter(class_id=stu_obj.class_id.class_id)[0].class_id,
                "class_name": ClassInfo.objects.filter(class_id=stu_obj.class_id.class_id)[0].class_name,
                "major_id": Major.objects.filter(major_id=stu_obj.major_id.major_id)[0].major_id,
                "major_name": Major.objects.filter(major_id=stu_obj.major_id.major_id)[0].major_name,
                "counselor_id": Counselor.objects.filter(counselor_id=
                                                           stu_obj.counselor_id.counselor_id)[0].counselor_id,
                "counselor_name": Counselor.objects.filter(counselor_id=
                                                           stu_obj.counselor_id.counselor_id)[0].counselor_name,
            }
            all_students_information['data_list'].append(temp_data)
        return JsonResponse(all_students_information, safe=False)
    else:
        return HttpResponse("Error")


# 获取单个学生的详细信息
def get_current_detail_student(request):
    if request.method == "GET":
        current_student_id = request.GET.get("student_id")
        student_detail = Student.objects.filter(student_id=current_student_id)[0]
        if student_detail:
            current_student_info = {
                "has_data": True,
                "data_list": {
                    "student_id": student_detail.student_id,
                    "student_name": student_detail.student_name,
                    "student_grade": student_detail.student_grade,
                    "student_nation": student_detail.student_nation,
                    "department_id": Department.objects.filter(department_id=student_detail.department_id.department_id
                                                                 )[0].department_id,
                    "department_name": Department.objects.filter(department_id=student_detail.department_id.department_id
                                                                 )[0].department_name,
                    "major_id": Major.objects.filter(major_id=student_detail.major_id.major_id)[0].major_id,
                    "major_name": Major.objects.filter(major_id=student_detail.major_id.major_id)[0].major_name,
                    "class_id": ClassInfo.objects.filter(class_id=student_detail.class_id.class_id)[0].class_id,
                    "class_name": ClassInfo.objects.filter(class_id=student_detail.class_id.class_id)[0].class_name,
                    "counselor_id": Counselor.objects.filter(counselor_id=student_detail.counselor_id.counselor_id
                                                             )[0].counselor_id,
                    "counselor_name": Counselor.objects.filter(counselor_id=student_detail.counselor_id.counselor_id
                                                               )[0].counselor_name,

                    "birth_date": student_detail.birth_date,
                    "length_of_schooling": student_detail.length_of_schooling,
                    "political_status": student_detail.political_status,
                    "native_place": student_detail.native_place,
                    "enrollment_date": student_detail.enrollment_date,
                    "dormitory_addr": student_detail.dormitory_addr,
                    "email": student_detail.email,
                    "phone": student_detail.phone,
                    "id_number": student_detail.id_number,
                },
            }
        else:
            current_student_info = {
                "has_data": False,
                "data_list": {},
            }
        print("当前学生ID:", current_student_id)
        return JsonResponse(current_student_info, safe=False)
    else:
        return HttpResponse("Error")
