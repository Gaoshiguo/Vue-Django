from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('get_all_student_information/', views.get_all_student_information),
    path('get_current_detail_student/', views.get_current_detail_student),
]
