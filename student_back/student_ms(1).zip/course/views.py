from django.shortcuts import render, HttpResponse
from student.models import Student, Score, Course
from django.http import JsonResponse

# Create your views here.


def index(request):
    return HttpResponse("This is the course index")


def get_current_student_score(request):
    if request.method == "GET":
        current_student_id = request.GET.get("student_id")
        if current_student_id is None or len(current_student_id) != 12:
            return HttpResponse("学号未给定或者学号错误")
        else:
            all_score_queryset = Score.objects.filter(student_id=current_student_id).all()
            # print(all_score_queryset)
            score_list = {
                "has_data": True,
                "data_list": [],
            }
            for each_score in all_score_queryset:
                # print(type(each_score))
                # print(each_score.course_id.course_id)
                is_failed = "否" if each_score.overall_score > 60 else "是"
                temp_data = {
                    "course_id": each_score.course_id.course_id,
                    "course_name": Course.objects.filter(course_id=each_score.course_id.course_id)[0].course_name,
                    "course_grade": each_score.course_grade,
                    "overall_score": each_score.overall_score,
                    "get_grade": each_score.get_grade,
                    "is_failed": is_failed,  # 表示是否挂科
                }
                score_list['data_list'].append(temp_data)
            return JsonResponse(score_list, safe=False)
    else:
        return HttpResponse("Error")


def get_current_student_detail_score(request):
    if request.method == "GET":
        current_student_id = request.GET.get("student_id")
        if current_student_id is None or len(current_student_id) != 12:
            return HttpResponse("学号未给定或者学号错误")
        else:
            all_score_queryset = Score.objects.filter(student_id=current_student_id).all()
            # print(all_score_queryset)
            score_list = {
                "has_data": True,
                "data_list": [],
            }
            for each_score in all_score_queryset:
                is_failed = "否" if each_score.overall_score > 60 else "是"
                temp_data = {
                    "score_id": each_score.score_id,
                    "course_id": each_score.course_id.course_id,
                    "course_name": Course.objects.filter(course_id=each_score.course_id.course_id)[0].course_name,
                    "course_type": each_score.course_type,
                    "course_grade": each_score.course_grade,
                    "semester": each_score.semester,
                    "part_time_score": each_score.part_time_score,  # 平时成绩
                    "exam_score": each_score.exam_score,  # 期末成绩
                    "overall_score": each_score.overall_score,  # 综合成绩
                    "get_grade": each_score.get_grade,
                    "postscript": each_score.postscript,  # 备注信息
                    "is_failed": is_failed,  # 表示是否挂科
                }
                score_list['data_list'].append(temp_data)
            return JsonResponse(score_list, safe=False)
    else:
        return HttpResponse("Error")
